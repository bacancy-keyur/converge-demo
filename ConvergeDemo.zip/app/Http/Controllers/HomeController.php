<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use wwwroth\Converge\Converge;
use function config;
use function view;

class HomeController extends Controller
{

    /**
     * Show the application dashboard.
     *
     * @return Renderable
     */
    public function index()
    {
        $converge = new Converge([
            'merchant_id' => config('app.evalon.account'),
            'user_id' => config('app.evalon.user'),
            'pin' => config('app.evalon.password'),
            'demo' => true,
        ]);

//        $generateToken = $converge->request('ccgettoken', [
//            'ssl_card_number' => '4124939999999990',
//            'ssl_exp_date' => '0120',
//            'ssl_cvv2cvc2' => '123',
//            'ssl_amount' => '100.00',
//            'ssl_avs_address' => 'TEST',
//            'ssl_avs_zip' => '9999',
//        ]);
//        $createSale = $converge->request('ccsale', [
//            'ssl_card_number' => '4124939999999990',
//            'ssl_exp_date' => '1220',
//            'ssl_cvv2cvc2' => '123',
//            'ssl_amount' => '789.00',
//            'ssl_avs_address' => 'TEST',
//            'ssl_avs_zip' => '9999',
//        ]);

        $createRecurring= $converge->request('ccaddrecurring', [
            'ssl_card_number' => '6011996666666667',
            'ssl_exp_date' => '1220',
            'ssl_cvv2cvc2' => '123',
            'ssl_amount' => '10.00',
            'ssl_avs_address' => 'TEST',
            'ssl_avs_zip' => '9999',
            'ssl_billing_cycle' => 'ANNUALLY',
            'ssl_next_payment_date' => '08/01/2019'
        ]);

        echo '<pre>';
        var_dump($createRecurring);
        exit;

        return view('home', get_defined_vars());
    }

}
