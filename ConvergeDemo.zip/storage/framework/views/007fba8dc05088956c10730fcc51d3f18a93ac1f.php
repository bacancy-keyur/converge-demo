<?php /* /var/www/html/converge-demo/resources/views/home.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Converge API</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <p>Generate token</p>
                    <table class="table table-bordered">
                        <tr>
                            <td>ssl_token</td>
                            <td>ssl_token_response</td>
                            <td>success</td>
                        </tr>
                        <tr>
                            <td><?php echo e($generateToken['ssl_token']); ?></td>
                            <td><?php echo e($generateToken['ssl_token_response']); ?></td>
                            <td><?php echo e($generateToken['success']); ?></td>
                        </tr>
                    </table>
                    <p>Create Scale</p>
                    <table class="table table-bordered">
                        <tr>
                            <td>ssl_txn_time</td>
                            <td>ssl_txn_id</td>
                            <td>success</td>
                        </tr>
                        <tr>
                            <td><?php echo e($createSale['ssl_txn_time']); ?></td>
                            <td><?php echo e($createSale['ssl_txn_id']); ?></td>
                            <td><?php echo e($createSale['success']); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>