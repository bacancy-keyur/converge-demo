@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Converge API</div>

                <div class="card-body">
                    @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                    @endif
                    <p>Generate token</p>
                    <table class="table table-bordered">
                        <tr>
                            <td>ssl_token</td>
                            <td>ssl_token_response</td>
                            <td>success</td>
                        </tr>
                        <tr>
                            <td>{{$generateToken['ssl_token']}}</td>
                            <td>{{$generateToken['ssl_token_response']}}</td>
                            <td>{{$generateToken['success']}}</td>
                        </tr>
                    </table>
                    <p>Create Scale</p>
                    <table class="table table-bordered">
                        <tr>
                            <td>ssl_txn_time</td>
                            <td>ssl_txn_id</td>
                            <td>success</td>
                        </tr>
                        <tr>
                            <td>{{$createSale['ssl_txn_time']}}</td>
                            <td>{{$createSale['ssl_txn_id']}}</td>
                            <td>{{$createSale['success']}}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
